<?php
session_start();

include "api/config.php";

$error = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){

    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    if(empty($username) || empty($password)){

        $error = "All fields are required.";

    }else{

        $stmt = $conn->prepare("
            SELECT id, username, password
            FROM admins
            WHERE username = ?
        ");

        $stmt->bind_param("s", $username);

        $stmt->execute();

        $result = $stmt->get_result();

        if($result->num_rows > 0){

            $admin = $result->fetch_assoc();

            if($password === $admin["password"]){

                $_SESSION["admin_id"] = $admin["id"];
                $_SESSION["admin_username"] = $admin["username"];

                header("Location: doctor_dashboard.php");
                exit;

            }else{

                $error = "Invalid password.";

            }

        }else{

            $error = "Admin not found.";

        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<title>HealthKiosk | Admin Login</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

html,
body{
    width:100%;
    height:100%;
    overflow:hidden;
}

body{
    min-height:100vh;
    display:grid;
    place-items:center;
    overflow:hidden;
    background:linear-gradient(135deg,#ffe4ec,#ffd6d6,#ffc1d6);
}

/* Login Card */
.login-box{
    width:100%;
    max-width:400px;
    background:rgba(255,255,255,0.95);
    backdrop-filter:blur(12px);
    border-radius:20px;
    padding:40px;
    box-shadow:0 15px 40px rgba(220,38,38,.15);
    border:1px solid rgba(255,255,255,.4);
}

/* Logo */
.logo{
    text-align:center;
    margin-bottom:15px;
}

.logo img{
    width:90px;
    height:90px;
    object-fit:contain;
}

/* Title */
.title{
    text-align:center;
    margin-bottom:30px;
}

.title h3{
    color:#d81b60;
    font-size:20px;
    font-weight:700;
    margin-bottom:6px;
}

.title p{
    color:#7f1d1d;
    font-size:15px;
}

/* Input */
.input-group{
    margin-bottom:20px;
}

.input-group label{
    display:block;
    margin-bottom:8px;
    font-size:14px;
    color:#9f1239;
    font-weight:600;
}

.input-group input{
    width:100%;
    padding:13px 15px;
    border:1px solid #f8b4c7;
    border-radius:12px;
    font-size:15px;
    background:#fff8fb;
    transition:.3s;
}

.input-group input:focus{
    outline:none;
    border-color:#e91e63;
    box-shadow:0 0 0 4px rgba(233,30,99,.15);
}

/* Button */
.btn{
    width:100%;
    padding:14px;
    border:none;
    border-radius:12px;
    background:linear-gradient(135deg,#ec407a,#d32f2f);
    color:#fff;
    font-size:16px;
    font-weight:600;
    cursor:pointer;
    transition:.3s;
}

.btn:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 20px rgba(211,47,47,.3);
}


/* Footer */
.footer{
    margin-top:25px;
    text-align:center;
    font-size:13px;
    color:#a1a1aa;
}

</style>

</head>
<body>

<div class="login-box">

    <!-- Logo -->
    <div class="logo">
        <img src=img/poz-logo.png alt="HealthKiosk Logo">
    </div>

    <!-- Title -->
    <div class="title">
        <h3>Pozorrubio HealthKiosk</h3>
        <p>Administrator Login</p>
    </div>

    <?php if(!empty($error)): ?>
        <script>
        Swal.fire({
        icon: 'error',
        title: 'Access Denied',
        text: '<?php echo addslashes($error); ?>',
        confirmButtonText: 'Try Again',
        confirmButtonColor: '#e91e63',
        background: '#fff8fb',
        color: '#7f1d1d',
        scrollbarPadding: false
    });
    </script>
<?php endif; ?>
    <form method="POST">

        <div class="input-group">
            <label>Username</label>
            <input
                type="text"
                name="username"
                placeholder="Enter your username"
                required
            >
        </div>

        <div class="input-group">
            <label>Password</label>
            <input
                type="password"
                name="password"
                placeholder="Enter your password"
                required
            >
        </div>

        <button type="submit" class="btn">
            Login
        </button>

    </form>

    <div class="footer">
        © <?php echo date("Y"); ?> HealthKiosk System
    </div>

</div>
</body>
</html>