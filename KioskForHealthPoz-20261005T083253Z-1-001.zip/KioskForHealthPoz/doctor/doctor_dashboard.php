<?php
session_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}
include "db.php";

$result = $conn->query("
    SELECT hr.id, p.first_name, p.last_name, p.age, p.barangay, p.gender, p.face_image,
           hr.weight_kg, hr.height_cm, hr.bmi,
           hr.temperature_c, hr.spo2_percent, hr.systolic_bp, hr.diastolic_bp, hr.pulse_bpm,
           hr.recorded_at
    FROM health_records hr
    INNER JOIN patients p ON hr.patient_id = p.id
    ORDER BY hr.id DESC
");
$totalRecords = $result->num_rows;

$notifications = [];
$nq = mysqli_query($conn,"
    SELECT hr.id, p.first_name, p.last_name,
           hr.systolic_bp, hr.diastolic_bp, hr.temperature_c, hr.spo2_percent, hr.pulse_bpm, hr.recorded_at
    FROM health_records hr INNER JOIN patients p ON hr.patient_id = p.id
    WHERE hr.systolic_bp>=140 OR hr.temperature_c>=37.5 OR hr.spo2_percent<95 OR hr.pulse_bpm>=100
    ORDER BY hr.recorded_at DESC
");
while($row = mysqli_fetch_assoc($nq)){
    $msg = "";
    if($row['systolic_bp']>=140)       $msg=$row['first_name']." ".$row['last_name']." has HIGH BLOOD PRESSURE (".$row['systolic_bp']."/".$row['diastolic_bp']." mmHg)";
    elseif($row['temperature_c']>=37.5) $msg=$row['first_name']." ".$row['last_name']." has FEVER (".$row['temperature_c']." °C)";
    elseif($row['spo2_percent']<95)     $msg=$row['first_name']." ".$row['last_name']." has LOW SpO2 (".$row['spo2_percent']."%)";
    elseif($row['pulse_bpm']>=100)      $msg=$row['first_name']." ".$row['last_name']." has HIGH HEART RATE (".$row['pulse_bpm']." bpm)";
    $notifications[] = ["name"=>$row['first_name']." ".$row['last_name'], "alert"=>$msg, "time"=>date("M d, Y h:i A", strtotime($row['recorded_at']))];
}

$weeklyData = [];
foreach(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $day){
    $r = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM health_records WHERE DAYNAME(recorded_at) LIKE '$day%'"));
    $weeklyData[] = intval($r['total']);
}

$highBP  = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM health_records WHERE systolic_bp>=140"))['t']);
$fever   = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM health_records WHERE temperature_c>=37.5"))['t']);
$lowSpo2 = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM health_records WHERE spo2_percent<95"))['t']);
$highHR  = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM health_records WHERE pulse_bpm>=100"))['t']);

$avg = mysqli_fetch_assoc(mysqli_query($conn,"SELECT AVG(systolic_bp) as bp, AVG(spo2_percent) as spo2, AVG(temperature_c) as temp, AVG(pulse_bpm) as hr, AVG(weight_kg) as weight, AVG(bmi) as bmi FROM health_records"));

$genderM = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM patients WHERE gender='Male'"))['t']);
$genderF = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM patients WHERE gender='Female'"))['t']);

$ageChild  = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM patients WHERE age<18"))['t']);
$ageAdult  = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM patients WHERE age>=18 AND age<60"))['t']);
$ageSenior = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM patients WHERE age>=60"))['t']);

$totalPatients = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM patients"))['t']);
$printedReports = $totalRecords;

$monthlyData = [];
$monthlyLabels = [];
for($i = 5; $i >= 0; $i--) {
    $r = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as total FROM health_records WHERE YEAR(recorded_at)=YEAR(DATE_SUB(NOW(), INTERVAL $i MONTH)) AND MONTH(recorded_at)=MONTH(DATE_SUB(NOW(), INTERVAL $i MONTH))"));
    $monthlyData[] = intval($r['total']);
    $monthlyLabels[] = date('M', strtotime("-$i months"));
}

$todayCount = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM health_records WHERE DATE(recorded_at)=CURDATE()"))['t']);
$weekCount  = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM health_records WHERE YEARWEEK(recorded_at,1)=YEARWEEK(CURDATE(),1)"))['t']);
$monthCount = intval(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) as t FROM health_records WHERE YEAR(recorded_at)=YEAR(CURDATE()) AND MONTH(recorded_at)=MONTH(CURDATE())"))['t']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>HealthKiosk — Admin Panel</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
:root {
  --green-950: #c92984;
  --green-900: #c92984;
  --green-800: #8b136f;
  --green-700: #8b313c;
  --green-600: #a3164c;
  --green-500: #22c55e;
  --green-400: #4ade80;
  --green-100: #dcfce7;
  --green-50:  #efc9e0;
  --slate-900: #0f172a;
  --slate-800: #1e293b;
  --slate-700: #334155;
  --slate-600: #475569;
  --slate-500: #64748b;
  --slate-400: #94a3b8;
  --slate-200: #f8e5f7;
  --slate-100: #f1f5f9;
  --slate-50:  #fcf8fb;
  --red-600:   #d17070;
  --red-100:   #fee2e2;
  --amber-500: #f59e0b;
  --amber-100: #fef3c7;
  --blue-600:  #2563eb;
  --blue-100:  #dbeafe;
  --sidebar-w: 256px;
  --topbar-h:  64px;
  --radius-sm: 6px;
  --radius:    10px;
  --radius-lg: 16px;
  --radius-xl: 22px;
  --shadow-sm: 0 1px 3px rgba(0,0,0,.06), 0 1px 2px rgba(0,0,0,.04);
  --shadow:    0 4px 12px rgba(0,0,0,.06);
  --shadow-lg: 0 12px 32px rgba(0,0,0,.1);
}
*, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
html, body { height:100%; font-family:'DM Sans',sans-serif; font-size:14px; color:var(--slate-800); background:var(--slate-100); }
body { overflow: hidden; }
.shell { display:flex; height:100vh; width: 100vw; }

.sidebar-brand{
    display:flex;
    align-items:center;
    gap:12px;
    padding:10px;
}

.brand-square{
    width:60px;
    height:60px;
    flex-shrink:0;
    display:flex;
    align-items:center;
    justify-content:center;
    margin-left:14px;
}

.brand-square img{
    width:60px;
    height:60px;
    object-fit:cover;
}

.sidebar { 
  width:var(--sidebar-w); 
  flex-shrink:0; 
  background:var(--green-950); 
  display:flex; 
  flex-direction:column; 
  height:100vh; 
  position:fixed; 
  left:0; 
  top:0; 
  z-index:100; 
  border-right:1px solid rgba(255,255,255,.04);
  transition: transform 0.3s ease;
}
.sidebar-brand { padding:24px 20px 20px; border-bottom:1px solid rgba(255,255,255,.06); }
.brand-mark { display:flex; align-items:center; gap:10px; margin-bottom:2px; }
.brand-square { width:32px; height:32px; background:var(--green-600); border-radius:var(--radius-sm); display:flex; align-items:center; justify-content:center; }
.brand-square svg { width:18px; height:18px; stroke:#fff; fill:none; stroke-width:2; stroke-linecap:round; stroke-linejoin:round; }
.brand-name { font-size:16px; font-weight:700; color:#fff; letter-spacing:-.3px; }
.brand-sub { font-size:11px; color:rgba(255,255,255,.4); margin-left:42px; margin-top:1px; }
.nav-section-label { font-size:10px; font-weight:600; letter-spacing:1.2px; text-transform:uppercase; color:rgba(255,255,255,.3); padding:20px 20px 8px; }
.nav-link { display:flex; align-items:center; gap:10px; padding:10px 12px; margin:2px 10px; border-radius:var(--radius); cursor:pointer; color:rgba(255,255,255,.6); font-size:13.5px; font-weight:500; transition:background .15s,color .15s; user-select:none; position:relative; }
.nav-link:hover { background:rgba(255,255,255,.06); color:rgba(255,255,255,.9); }
.nav-link.active { background:var(--green-600); color:#fff; font-weight:600; }
.nav-link svg { width:16px; height:16px; flex-shrink:0; stroke:currentColor; fill:none; stroke-width:1.75; stroke-linecap:round; stroke-linejoin:round; }
.nav-badge { margin-left:auto; background:var(--red-600); color:#fff; font-size:10px; font-weight:700; padding:2px 6px; border-radius:999px; min-width:18px; text-align:center; }
.sidebar-footer { margin-top:auto; border-top:1px solid rgba(255,255,255,.06); padding:16px; }
.admin-card { background:rgba(255,255,255,.06); border-radius:var(--radius); padding:12px 14px; display:flex; align-items:center; gap:10px; }
.admin-avatar { width:36px; height:36px; border-radius:var(--radius-sm); background:var(--green-700); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.admin-avatar svg { width:18px; height:18px; stroke:#fff; fill:none; stroke-width:1.75; stroke-linecap:round; stroke-linejoin:round; }
.admin-name { font-size:12px; font-weight:600; color:#fff; }
.admin-role { font-size:11px; color:rgba(255,255,255,.45); margin-top:1px; }
.logout-link { display:block; text-align:center; margin-top:10px; padding:9px; border:1px solid rgba(255,255,255,.1); border-radius:var(--radius); color:rgba(255,255,255,.55); font-size:12px; font-weight:500; cursor:pointer; text-decoration:none; transition:.15s; }
.logout-link:hover { background:var(--red-600); border-color:var(--red-600); color:#fff; }

.main { margin-left:var(--sidebar-w); flex:1; display:flex; flex-direction:column; height:100vh; overflow:hidden; width: calc(100vw - var(--sidebar-w)); transition: margin-left 0.3s ease, width 0.3s ease; }
.topbar { height:var(--topbar-h); background:#fff; border-bottom:1px solid var(--slate-200); display:flex; align-items:center; padding:0 24px; gap:12px; flex-shrink:0; }
.menu-btn { display: none; width: 36px; height: 36px; border: 1px solid var(--slate-200); background: var(--slate-50); border-radius: var(--radius); align-items: center; justify-content: center; cursor: pointer; }
.menu-btn svg { width: 18px; height: 18px; stroke: var(--slate-700); fill: none; stroke-width: 2; stroke-linecap: round; }
.topbar-title { font-size:16px; font-weight:700; color:var(--slate-900); letter-spacing:-.4px; white-space: nowrap; }
.topbar-sub { font-size:11px; color:var(--slate-400); margin-left:4px; font-weight:400; display: inline-block; }
.topbar-right { margin-left:auto; display:flex; align-items:center; gap:6px; }
.topbar-btn { width:34px; height:34px; border:1px solid var(--slate-200); background:var(--slate-50); border-radius:var(--radius); display:flex; align-items:center; justify-content:center; cursor:pointer; transition:.15s; position:relative; }
.topbar-btn:hover { border-color:var(--green-600); background:var(--green-50); }
.topbar-btn svg { width:15px; height:15px; stroke:var(--slate-600); fill:none; stroke-width:1.75; stroke-linecap:round; stroke-linejoin:round; }
.notif-dot { position:absolute; top:-3px; right:-3px; width:16px; height:16px; background:var(--red-600); border-radius:50%; border:2px solid #fff; font-size:9px; color:#fff; font-weight:700; display:flex; align-items:center; justify-content:center; }
.clock-pill { background:var(--green-900); color:#fff; padding:6px 10px; border-radius:var(--radius); font-family:'DM Mono',monospace; font-size:11.5px; font-weight:500; letter-spacing:.5px; white-space: nowrap; }

.content { flex:1; overflow-y:auto; padding:20px; scrollbar-width:thin; scrollbar-color:var(--slate-300) transparent; -webkit-overflow-scrolling: touch; }
.page { display:none; }
.page.active { display:block; }
.card { background:#fff; border:1px solid var(--slate-200); border-radius:var(--radius-lg); box-shadow:var(--shadow-sm); margin-bottom: 16px; }
.card-head { display:flex; align-items:flex-start; justify-content:space-between; padding:16px 20px; border-bottom:1px solid var(--slate-100); gap: 10px; }
.card-title { font-size:13.5px; font-weight:700; color:var(--slate-800); }
.card-sub { font-size:11px; color:var(--slate-400); margin-top:2px; }
.card-body { padding:16px 20px; }
.btn-ghost { border:1px solid var(--slate-200); background:var(--slate-50); border-radius:var(--radius-sm); padding:6px 11px; font-family:'DM Sans',sans-serif; font-size:11.5px; font-weight:600; color:var(--slate-600); cursor:pointer; transition:.15s; white-space:nowrap; }
.btn-ghost:hover { background:var(--green-600); color:#fff; border-color:var(--green-600); }
.btn-green { border:1px solid var(--green-600); background:var(--green-50); border-radius:var(--radius-sm); padding:6px 11px; font-family:'DM Sans',sans-serif; font-size:11.5px; font-weight:600; color:var(--green-700); cursor:pointer; transition:.15s; white-space: nowrap; }
.btn-green:hover { background:var(--green-600); color:#fff; }

.stat-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(140px, 1fr)); gap:12px; margin-bottom:20px; }
.stat-card { background:#fff; border:1px solid var(--slate-200); border-radius:var(--radius-lg); padding:16px; position:relative; overflow:hidden; transition:transform .2s,box-shadow .2s; }
.stat-card:hover { transform:translateY(-2px); box-shadow:var(--shadow); }
.stat-card::before { content:''; position:absolute; bottom:0; left:0; right:0; height:3px; }
.stat-card.s-green::before  { background:var(--green-500); }
.stat-card.s-red::before    { background:var(--red-600); }
.stat-card.s-amber::before  { background:var(--amber-500); }
.stat-card.s-blue::before   { background:var(--blue-600); }
.stat-label { font-size:10px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; color:var(--slate-400); margin-bottom:6px; }
.stat-val { font-size:28px; font-weight:700; color:var(--slate-900); letter-spacing:-1px; line-height:1; font-family:'DM Mono',monospace; }
.stat-val-unit { font-size:12px; font-weight:500; color:var(--slate-400); margin-left:2px; }
.stat-change { margin-top:6px; font-size:11px; color:var(--slate-500); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

.tbl-wrap { overflow-x:auto; width: 100%; -webkit-overflow-scrolling: touch; }
table { width:100%; border-collapse:collapse; min-width: 500px; }
thead th { text-align:left; padding:10px 12px; font-size:10px; font-weight:700; color:var(--slate-400); text-transform:uppercase; letter-spacing:.5px; border-bottom:1px solid var(--slate-100); background:var(--slate-50); white-space:nowrap; }
tbody td { padding:10px 12px; border-bottom:1px solid var(--slate-100); font-size:12.5px; vertical-align:middle; white-space: nowrap; }
tbody tr { transition:background .12s; cursor:pointer; }
tbody tr:hover { background:var(--green-50); }
tbody tr:last-child td { border-bottom:none; }
.mono { font-family:'DM Mono',monospace; font-size:12px; }
.badge { display:inline-flex; align-items:center; padding:2px 8px; border-radius:999px; font-size:10px; font-weight:700; white-space:nowrap; }
.badge-ok    { background:var(--green-100); color:#166534; }
.badge-warn  { background:var(--amber-100); color:#92400e; }
.badge-alert { background:var(--red-100);   color:var(--red-600); }
.badge-blue  { background:var(--blue-100);  color:var(--blue-600); }
.badge-gray  { background:var(--slate-100); color:var(--slate-600); }
.pt-cell { display:flex; align-items:center; gap:8px; }
.pt-av { width:30px; height:30px; border-radius:50%; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:11px; font-weight:700; color:#fff; overflow:hidden; }
.pt-av img { width:100%; height:100%; object-fit:cover; }
.pt-name { font-weight:600; font-size:12.5px; }
.pt-sub { font-size:10.5px; color:var(--slate-400); }

.alert-row { display:flex; gap:10px; padding:12px 0; border-bottom:1px solid var(--slate-100); }
.alert-row:last-child { border-bottom:none; }
.alert-pip { width:8px; height:8px; border-radius:50%; flex-shrink:0; margin-top:5px; }
.pip-red   { background:var(--red-600); }
.pip-amber { background:var(--amber-500); }
.pip-green { background:var(--green-500); }
.alert-title { font-size:12.5px; font-weight:600; }
.alert-meta { font-size:11px; color:var(--slate-400); margin-top:2px; }

.toolbar { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:16px; align-items:center; }
.search-box { display:flex; align-items:center; gap:8px; background:#fff; border:1px solid var(--slate-200); border-radius:var(--radius); padding:8px 12px; flex:1; min-width:180px; }
.search-box svg { width:14px; height:14px; stroke:var(--slate-400); fill:none; stroke-width:2; stroke-linecap:round; }
.search-box input { border:none; background:none; outline:none; font-family:'DM Sans',sans-serif; font-size:12.5px; width:100%; }
.filter-select { border:1px solid var(--slate-200); background:#fff; border-radius:var(--radius); padding:8px 10px; font-family:'DM Sans',sans-serif; font-size:12px; color:var(--slate-700); cursor:pointer; outline:none; flex: 1; min-width: 110px; }

.date-input { border:1px solid var(--slate-200); background:#fff; border-radius:var(--radius); padding:7px 10px; font-family:'DM Sans',sans-serif; font-size:12px; color:var(--slate-700); cursor:pointer; outline:none; }
.period-tabs { display:flex; background:var(--slate-100); border-radius:var(--radius); padding:3px; gap:2px; flex-wrap: wrap; width: 100%; }
.period-tab { padding:6px 10px; border-radius:var(--radius-sm); font-size:11.5px; font-weight:600; cursor:pointer; transition:.15s; color:var(--slate-500); border:none; background:none; font-family:'DM Sans',sans-serif; flex: 1; text-align: center; white-space: nowrap; }
.period-tab.active { background:#fff; color:var(--green-700); box-shadow:var(--shadow-sm); }

.export-wrap { position:relative; display:inline-block; }
.export-menu { display:none; position:absolute; top:calc(100% + 4px); left:0; background:#fff; border:1px solid var(--slate-200); border-radius:var(--radius); box-shadow:var(--shadow); z-index:50; min-width:180px; }
.export-menu.open { display:block; }
.export-item { display:block; padding:9px 16px; font-size:12.5px; font-weight:500; color:var(--slate-700); cursor:pointer; transition:background .12s; white-space:nowrap; }
.export-item:hover { background:var(--green-50); color:var(--green-700); }
.export-divider { height:1px; background:var(--slate-100); margin:4px 0; }

.drawer-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.25); z-index:200; backdrop-filter:blur(2px); }
.drawer-overlay.open { display:block; }
.drawer { position:fixed; top:0; right:0; bottom:0; width:100%; max-width:400px; background:#fff; z-index:201; transform:translateX(100%); transition:transform .3s cubic-bezier(.4,0,.2,1); overflow-y:auto; box-shadow:-8px 0 48px rgba(0,0,0,.12); }
.drawer.open { transform:translateX(0); }
.drawer-head { position:sticky; top:0; background:#fff; padding:16px 20px; border-bottom:1px solid var(--slate-100); display:flex; align-items:center; gap:12px; }
.drawer-av { width:42px; height:42px; border-radius:10px; background:var(--green-700); display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:700; color:#fff; flex-shrink:0; overflow:hidden; }
.drawer-av img { width:100%; height:100%; object-fit:cover; }
.drawer-name { font-size:15px; font-weight:700; letter-spacing:-.3px; }
.drawer-id { font-size:11px; color:var(--slate-400); margin-top:2px; }
.drawer-close { margin-left:auto; width:30px; height:30px; border:1px solid var(--slate-200); background:var(--slate-50); border-radius:var(--radius-sm); cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:12px; color:var(--slate-500); }
.drawer-body { padding:16px 20px; }
.drawer-section { margin-bottom:20px; }
.drawer-section-title { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:var(--slate-400); margin-bottom:10px; }
.info-grid { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
.info-tile { background:var(--slate-50); border:1px solid var(--slate-100); border-radius:var(--radius); padding:10px 12px; }
.info-tile-label { font-size:9px; color:var(--slate-400); text-transform:uppercase; letter-spacing:.8px; margin-bottom:2px; }
.info-tile-val { font-size:13px; font-weight:700; }
.vital-row { display:flex; align-items:center; gap:10px; padding:10px 0; border-bottom:1px solid var(--slate-100); }
.vital-row:last-child { border-bottom:none; }
.vital-name { font-size:12.5px; color:var(--slate-600); flex:1; }
.vital-val { font-family:'DM Mono',monospace; font-size:13px; font-weight:500; }

.dash-grid { display:grid; grid-template-columns:1fr 300px; gap:16px; }
.col { display:flex; flex-direction:column; gap:16px; }
.chart-container { position: relative; height: 180px; width: 100%; }
.vital-avg-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(130px, 1fr)); gap:12px; margin-bottom:20px; }
.vital-avg-card { background:#fff; border:1px solid var(--slate-200); border-radius:var(--radius-lg); padding:16px; }
.vac-label { font-size:10px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; color:var(--slate-400); margin-bottom:6px; }
.vac-val { font-family:'DM Mono',monospace; font-size:24px; font-weight:700; letter-spacing:-1px; }
.vac-unit { font-size:12px; color:var(--slate-400); margin-left:2px; }
.report-stat-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(130px, 1fr)); gap:12px; margin-bottom:16px; }
.analytics-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:16px; margin-bottom:20px; }
.settings-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:16px; }
.setting-row { display:flex; align-items:center; justify-content:space-between; padding:12px 0; border-bottom:1px solid var(--slate-100); gap: 10px; }
.setting-row:last-child { border-bottom:none; }
.setting-label { font-size:13px; font-weight:600; }
.setting-sub { font-size:11px; color:var(--slate-400); margin-top:2px; }
.toggle { width:36px; height:20px; background:var(--green-500); border-radius:999px; cursor:pointer; position:relative; flex-shrink:0; }
.toggle::after { content:''; position:absolute; left:2px; top:2px; width:16px; height:16px; background:#fff; border-radius:50%; transition:.2s; }
.toggle.off { background:var(--slate-300); }
.toggle.off::after { left:calc(100% - 18px); }
.form-input { border:1px solid var(--slate-200); border-radius:var(--radius); padding:8px 12px; font-family:'DM Sans',sans-serif; font-size:12.5px; width:100%; outline:none; }
.form-group { margin-bottom:12px; }
.form-label { font-size:11.5px; font-weight:600; color:var(--slate-600); margin-bottom:4px; display:block; }
.form-select { border:1px solid var(--slate-200); border-radius:var(--radius); padding:8px 12px; font-family:'DM Sans',sans-serif; font-size:12.5px; width:100%; outline:none; background:#fff; }

.modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.4); z-index:300; align-items:center; justify-content:center; backdrop-filter:blur(4px); padding: 16px; }
.modal-overlay.open { display:flex; }
.modal { background:#fff; border-radius:var(--radius-xl); padding:24px; width:100%; max-width:440px; box-shadow:var(--shadow-lg); animation:fadeUp .25s ease; }
@keyframes fadeUp { from{opacity:0;transform:translateY(12px)} to{opacity:1;transform:translateY(0)} }
.modal-title { font-size:16px; font-weight:700; margin-bottom:4px; letter-spacing:-.3px; }
.modal-sub { font-size:12px; color:var(--slate-500); margin-bottom:16px; }
.modal-actions { display:flex; gap:8px; margin-top:20px; justify-content:flex-end; }
.btn-primary { background:var(--green-600); color:#fff; border:none; border-radius:var(--radius); padding:9px 16px; font-family:'DM Sans',sans-serif; font-size:12.5px; font-weight:600; cursor:pointer; transition:.15s; }
.btn-outline { background:#fff; color:var(--slate-700); border:1px solid var(--slate-200); border-radius:var(--radius); padding:9px 16px; font-family:'DM Sans',sans-serif; font-size:12.5px; font-weight:600; cursor:pointer; transition:.15s; }
.empty-state { text-align:center; padding:32px 16px; color:var(--slate-400); font-size:12.5px; }

.sidebar-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.4); z-index: 99; backdrop-filter: blur(1px); }
.sidebar-overlay.open { display: block; }

/* ── RESPONSIVE DESIGN BREAKPOINTS ────────────────────────── */
@media(max-width:1024px) {
  .sidebar { transform: translateX(-100%); }
  .sidebar.open { transform: translateX(0); }
  .main { margin-left: 0; width: 100vw; }
  .menu-btn { display: flex; }
}

@media(max-width:768px) {
  .dash-grid { grid-template-columns: 1fr; }
  .stat-grid { grid-template-columns: repeat(2, 1fr); }
  .vital-avg-grid { grid-template-columns: repeat(2, 1fr); }
  .topbar-sub { display: none; }
  .toolbar { flex-direction: column; align-items: stretch; }
  .toolbar > * { width: 100%; }
  .search-box { min-width: 100%; }
  .export-wrap { width: 100%; }
  .export-wrap button { width: 100%; text-align: left; display: flex; justify-content: space-between; align-items: center; }
  .export-menu { width: 100%; }
}

/* 6-Inch Compact Terminal Display Mode (<440px viewport footprint) */
@media(max-width:440px) {
  body { font-size: 13px; }
  .topbar { padding: 0 12px; gap: 8px; }
  .clock-pill { display: none; }
  .content { padding: 12px; }
  .stat-grid { grid-template-columns: 1fr; gap: 8px; }
  .vital-avg-grid { grid-template-columns: 1fr; gap: 8px; }
  .card-head { padding: 12px 14px; flex-direction: column; align-items: flex-start; }
  .card-head button, .card-head div { width: 100%; }
  .card-body { padding: 12px 14px; }
  .info-grid { grid-template-columns: 1fr; }
  .modal { padding: 16px; }
  .modal-actions { flex-direction: column; }
  .modal-actions button { width: 100%; }
  .period-tabs { flex-direction: column; background: none; gap: 4px; padding: 0; }
  .period-tab { background: var(--slate-200); border-radius: var(--radius-sm); padding: 8px; }
  .period-tab.active { background: var(--green-600); color: #fff; }
  
  /* Date quick range alignments */
  div[style*="display:flex;align-items:center;gap:6px;margin-left:auto"] {
    margin-left: 0 !important;
    width: 100%;
    flex-wrap: wrap;
    margin-top: 8px;
  }
  .date-input { flex: 1; min-width: 100px; }
}

@media print {
  .sidebar, .topbar, .toolbar, .btn-ghost, .btn-green, .sidebar-overlay { display:none!important }
  .main { margin-left:0; width: 100%; }
  .content { padding:0; overflow: visible; }
}
</style>
</head>
<body>

<div class="sidebar-overlay" id="sidebarOverlay" onclick="toggleMobileSidebar()"></div>

<div class="shell">

<aside class="sidebar" id="sidebarNav">
<div class="sidebar-brand">
    <div class="brand-square">
        <img src="img/poz-logo.png" alt="HealthKiosk Logo">
    </div>
    <div style="display:flex; flex-direction:column;">
        <span class="brand-sub" style="font-size:20px; font-weight:700; color:#fff;">
    HealthKiosk
</span>

<span class="brand-sub" style="font-size:13px; color:#ffd6e7; margin-top:5px;">
    RHU Pozorrubio
</span>
    </div>
</div>
  <div class="nav-section-label">Main</div>
  <div class="nav-link active" onclick="nav('dashboard',this)">
    <svg viewBox="0 0 24 24"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
    Dashboard
  </div>
  <div class="nav-link" onclick="nav('patients',this)">
    <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
    Patients
  </div>
  <div class="nav-link" onclick="nav('vitals',this)">
    <svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
    Vital Monitoring
  </div>
  <div class="nav-section-label">Reports</div>
  <div class="nav-link" onclick="nav('reports',this)">
    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
    Reports Printed
  </div>
  <div class="nav-link" onclick="nav('analytics',this)">
    <svg viewBox="0 0 24 24"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
    Analytics
  </div>
  <div class="nav-section-label">System</div>
  <div class="nav-link" onclick="nav('notifications',this)" id="navNotif">
    <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
    Notifications
    <span class="nav-badge" id="navNotifBadge">0</span>
  </div>
  <div class="nav-link" onclick="nav('settings',this)">
    <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
    Settings
  </div>
  <div class="sidebar-footer">
    <div class="admin-card">
      <div class="admin-avatar">
        <svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      </div>
      <div>
        <div class="admin-name"><?php echo htmlspecialchars($_SESSION['admin_username']); ?></div>
        <div class="admin-role">ADMINISTRATOR</div>
      </div>
    </div>
    <a href="doctor_logout.php" class="logout-link">Sign Out</a>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <button class="menu-btn" onclick="toggleMobileSidebar()" title="Toggle Sidebar">
      <svg viewBox="0 0 24 24"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
    </button>
    <div>
      <span class="topbar-title" id="pageTitle">Dashboard</span>
      <span class="topbar-sub" id="pageSub">Overview &amp; Monitoring</span>
    </div>
    <div class="topbar-right">
      <button class="topbar-btn" title="Notifications" onclick="nav('notifications', document.querySelectorAll('.nav-link')[6])">
        <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
        <span class="notif-dot" id="topNotifBadge" style="display:none">0</span>
      </button>
      <button class="topbar-btn" title="Refresh" onclick="location.reload()">
        <svg viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
      </button>
      <div class="clock-pill" id="clock">00:00:00</div>
    </div>
  </div>

  <div class="content">

  <div class="page active" id="page-dashboard">
    <div class="stat-grid">
      <div class="stat-card s-green">
        <div class="stat-label">Total Patients</div>
        <div class="stat-val"><?php echo $totalPatients; ?></div>
        <div class="stat-change">Registered in system</div>
      </div>
      <div class="stat-card s-blue">
        <div class="stat-label">Completed Scans</div>
        <div class="stat-val"><?php echo $totalRecords; ?></div>
        <div class="stat-change">Health records saved</div>
      </div>
      <div class="stat-card s-red">
        <div class="stat-label">Flagged Vitals</div>
        <div class="stat-val"><?php echo $highBP+$fever+$lowSpo2+$highHR; ?></div>
        <div class="stat-change">Require attention</div>
      </div>
      <div class="stat-card s-amber">
        <div class="stat-label">Reports Printed</div>
        <div class="stat-val"><?php echo $printedReports; ?></div>
        <div class="stat-change">Total generated</div>
      </div>
    </div>
    <div class="dash-grid">
      <div class="col">
        <div class="card">
          <div class="card-head">
            <div><div class="card-title">Recent Patient Records</div><div class="card-sub">Last 8 scan sessions</div></div>
            <button class="btn-ghost" onclick="nav('patients', document.querySelectorAll('.nav-link')[1])">View All</button>
          </div>
          <div class="tbl-wrap">
            <table>
              <thead><tr><th>Patient</th><th>Barangay</th><th>Time</th><th>BP</th><th>SpO2</th><th>Temp</th><th>Status</th></tr></thead>
              <tbody id="recentTable"></tbody>
            </table>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(240px, 1fr));gap:16px">
          <div class="card">
            <div class="card-head"><div><div class="card-title">Daily Volume</div><div class="card-sub">Patients this week</div></div></div>
            <div class="card-body"><div class="chart-container"><canvas id="volChart"></canvas></div></div>
          </div>
          <div class="card">
            <div class="card-head"><div><div class="card-title">Vital Flags</div><div class="card-sub">Abnormal readings</div></div></div>
            <div class="card-body"><div class="chart-container"><canvas id="flagChart"></canvas></div></div>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card">
          <div class="card-head">
            <div><div class="card-title">Active Alerts</div><div class="card-sub">Requires attention</div></div>
            <button class="btn-ghost" onclick="nav('notifications', document.querySelectorAll('.nav-link')[6])">All</button>
          </div>
          <div class="card-body" id="dashAlerts"></div>
        </div>
        <div class="card">
          <div class="card-head"><div><div class="card-title">Demographics</div><div class="card-sub">Gender split</div></div></div>
          <div class="card-body"><div class="chart-container"><canvas id="genderChart"></canvas></div></div>
        </div>
        <div class="card">
          <div class="card-head"><div><div class="card-title">Age Groups</div><div class="card-sub">Patient distribution</div></div></div>
          <div class="card-body">
            <div style="display:flex;flex-direction:column;gap:10px">
              <div>
                <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:12px;font-weight:600">Children (&lt;18)</span><span style="font-size:12px;font-family:'DM Mono',monospace"><?php echo $ageChild; ?></span></div>
                <div style="height:6px;background:var(--slate-100);border-radius:999px"><div style="height:100%;width:<?php echo $totalPatients>0?round($ageChild/$totalPatients*100):0; ?>%;background:var(--blue-600);border-radius:999px"></div></div>
              </div>
              <div>
                <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:12px;font-weight:600">Adults (18–59)</span><span style="font-size:12px;font-family:'DM Mono',monospace"><?php echo $ageAdult; ?></span></div>
                <div style="height:6px;background:var(--slate-100);border-radius:999px"><div style="height:100%;width:<?php echo $totalPatients>0?round($ageAdult/$totalPatients*100):0; ?>%;background:var(--green-500);border-radius:999px"></div></div>
              </div>
              <div>
                <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="font-size:12px;font-weight:600">Seniors (60+)</span><span style="font-size:12px;font-family:'DM Mono',monospace"><?php echo $ageSenior; ?></span></div>
                <div style="height:6px;background:var(--slate-100);border-radius:999px"><div style="height:100%;width:<?php echo $totalPatients>0?round($ageSenior/$totalPatients*100):0; ?>%;background:var(--amber-500);border-radius:999px"></div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="page" id="page-patients">
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;flex-wrap:wrap">
      <div class="period-tabs">
        <button class="period-tab active" id="tabAll"   onclick="setPeriod('all')">All Records</button>
        <button class="period-tab"        id="tabToday" onclick="setPeriod('today')">Today (<?php echo $todayCount; ?>)</button>
        <button class="period-tab"        id="tabWeek"  onclick="setPeriod('week')">Week (<?php echo $weekCount; ?>)</button>
        <button class="period-tab"        id="tabMonth" onclick="setPeriod('month')">Month (<?php echo $monthCount; ?>)</button>
      </div>
      <div style="display:flex;align-items:center;gap:6px;margin-left:auto; width: 100%; flex-wrap: wrap;">
        <span style="font-size:12px;color:var(--slate-400);font-weight:600">Custom:</span>
        <input type="date" class="date-input" id="dateFrom" onchange="filterByDateRange()">
        <span style="font-size:12px;color:var(--slate-400)">to</span>
        <input type="date" class="date-input" id="dateTo" onchange="filterByDateRange()">
        <button class="btn-ghost" onclick="clearDateRange()" style="padding:7px 10px;font-size:11px">✕ Clear</button>
      </div>
    </div>

    <div class="toolbar">
      <div class="search-box">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input type="text" placeholder="Search name, barangay…" oninput="filterPatients(this.value)" id="patientSearch">
      </div>
      <div class="export-wrap" id="exportWrap">
        <button class="btn-green" onclick="toggleExportMenu()">Export ▾</button>
        <div class="export-menu" id="exportMenu">
          <div class="export-item" onclick="exportCSV('all');closeExportMenu()">Export All Records</div>
          <div class="export-item" onclick="exportCSV('today');closeExportMenu()">Export Today</div>
          <div class="export-item" onclick="exportCSV('week');closeExportMenu()">Export This Week</div>
          <div class="export-item" onclick="exportCSV('month');closeExportMenu()">Export This Month</div>
          <div class="export-divider"></div>
          <div class="export-item" onclick="exportCSV('range');closeExportMenu()">Export by Date Range</div>
          <div class="export-item" onclick="exportCSV('filtered');closeExportMenu()">Export Current View</div>
        </div>
      </div>
      <select class="filter-select" onchange="resetFilters('sf');filterByStatus(this.value)" id="sf">
        <option value="">All Status</option><option value="normal">Normal</option><option value="warning">Flagged</option>
      </select>
      <select class="filter-select" onchange="resetFilters('bpf');filterByBP(this.value)" id="bpf">
        <option value="">All BP</option><option value="normal">Normal BP</option><option value="high">High BP</option>
      </select>
      <select class="filter-select" onchange="resetFilters('tf');filterByTemp(this.value)" id="tf">
        <option value="">All Temp</option><option value="normal">Normal</option><option value="fever">Fever</option><option value="high">High Fever</option>
      </select>
      <select class="filter-select" onchange="resetFilters('sf2');filterBySpO2(this.value)" id="sf2">
        <option value="">All SpO2</option><option value="normal">Normal (≥95%)</option><option value="low">Low (90–94%)</option><option value="critical">Critical (&lt;90%)</option>
      </select>
      <select class="filter-select" onchange="resetFilters('af');filterByAddress(this.value)" id="af">
        <option value="">All Barangay</option>
        <?php
        $brgys = ["Alipangpang","Amagbagan","Balacag","Banding","Batakil","Bantugan","Bobonan","Buneg","Cablong","Casanfernandoan","Castano","Dilan","Don Benito","Haway","Imbalbalatong","Inoman","Laoac","Maambal","Malasin","Malokiat","Manaol","Nama","Nantangalan","Palacpalac","Palguyod","Poblacion District I","Poblacion District II","Poblacion District III","Poblacion District IV","Rosario","Sugcong","Talogtog","Tulnac","Villegas"];
        foreach($brgys as $b) echo "<option value=\"$b\">$b</option>\n";
        ?>
      </select>
    </div>
    <div class="card">
      <div class="card-head">
        <div><div class="card-title">Patient Records</div><div class="card-sub" id="ptCount">Loading…</div></div>
      </div>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>Patient</th><th>Barangay</th><th>Age / Gender</th><th>Weight</th><th>Height / BMI</th><th>BP</th><th>SpO2</th><th>Temp</th><th>HR</th><th>Time</th><th>Status</th></tr></thead>
          <tbody id="patientTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="page" id="page-vitals">
    <div class="vital-avg-grid">
      <div class="vital-avg-card"><div class="vac-label">Avg Systolic BP</div><div class="vac-val"><?php echo round($avg['bp']??0,1); ?><span class="vac-unit">mmHg</span></div></div>
      <div class="vital-avg-card"><div class="vac-label">Avg SpO2</div><div class="vac-val"><?php echo round($avg['spo2']??0,1); ?><span class="vac-unit">%</span></div></div>
      <div class="vital-avg-card"><div class="vac-label">Avg Temperature</div><div class="vac-val"><?php echo round($avg['temp']??0,1); ?><span class="vac-unit">°C</span></div></div>
      <div class="vital-avg-card"><div class="vac-label">Avg Heart Rate</div><div class="vac-val"><?php echo round($avg['hr']??0,1); ?><span class="vac-unit">bpm</span></div></div>
      <div class="vital-avg-card"><div class="vac-label">Avg Weight</div><div class="vac-val"><?php echo round($avg['weight']??0,1); ?><span class="vac-unit">kg</span></div></div>
      <div class="vital-avg-card"><div class="vac-label">Avg BMI</div><div class="vac-val"><?php echo round($avg['bmi']??0,1); ?></div></div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(280px, 1fr));gap:16px;margin-bottom:20px">
      <div class="card">
        <div class="card-head"><div><div class="card-title">Flagged Conditions Summary</div><div class="card-sub">Abnormal reading counts</div></div></div>
        <div class="card-body">
          <div style="display:flex;flex-direction:column;gap:14px">
            <?php
            $flags = [
              ['High Blood Pressure (≥140 mmHg)', $highBP,  '#dc2626', $totalRecords],
              ['Fever (≥37.5 °C)',                 $fever,   '#f59e0b', $totalRecords],
              ['Low SpO2 (<95%)',                  $lowSpo2, '#2563eb', $totalRecords],
              ['High Heart Rate (≥100 bpm)',        $highHR,  '#7c3aed', $totalRecords],
            ];
            foreach($flags as $f) {
              $pct = $f[3]>0 ? round($f[1]/$f[3]*100) : 0;
              echo "<div>
                <div style='display:flex;justify-content:space-between;margin-bottom:5px;'>
                  <span style='font-size:12.5px;font-weight:600'>{$f[0]}</span>
                  <span style='font-family:DM Mono,monospace;font-size:12px'>{$f[1]} <span style='color:var(--slate-400)'>({$pct}%)</span></span>
                </div>
                <div style='height:7px;background:var(--slate-100);border-radius:999px;'>
                  <div style='height:100%;width:{$pct}%;background:{$f[2]};border-radius:999px;transition:.6s'></div>
                </div>
              </div>";
            }
            ?>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><div><div class="card-title">BP Distribution</div><div class="card-sub">Normal vs. High</div></div></div>
        <div class="card-body"><div class="chart-container"><canvas id="bpDistChart"></canvas></div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><div><div class="card-title">All Patient Vitals</div><div class="card-sub">Full vital signs table</div></div></div>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>Patient</th><th>BP</th><th>SpO2</th><th>Temp</th><th>HR</th><th>Weight</th><th>BMI</th><th>Time</th><th>Status</th></tr></thead>
          <tbody id="vitalsTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="page" id="page-reports">
    <div class="report-stat-grid">
      <div class="stat-card s-green"><div class="stat-label">Total Reports</div><div class="stat-val"><?php echo $printedReports; ?></div><div class="stat-change">All time</div></div>
      <div class="stat-card s-blue"><div class="stat-label">This Week</div><div class="stat-val"><?php echo array_sum($weeklyData); ?></div><div class="stat-change">Mon – Sun</div></div>
      <div class="stat-card s-amber"><div class="stat-label">Flagged Reports</div><div class="stat-val"><?php echo $highBP+$fever+$lowSpo2+$highHR; ?></div><div class="stat-change">With abnormal vitals</div></div>
    </div>
    <div class="toolbar">
      <div class="search-box">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input type="text" placeholder="Search reports…" oninput="filterReports(this.value)">
      </div>
      <select class="filter-select" onchange="filterReportStatus(this.value)">
        <option value="">All Status</option><option value="normal">Normal</option><option value="warning">Flagged</option>
      </select>
      <button class="btn-green" onclick="exportCSV('all')">Export CSV</button>
      <button class="btn-ghost" onclick="window.print()">Print Page</button>
    </div>
    <div class="card">
      <div class="card-head"><div><div class="card-title">Printed Health Reports</div><div class="card-sub" id="reportCount">All records</div></div></div>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>Patient</th><th>Barangay</th><th>Date &amp; Time</th><th>BP</th><th>SpO2</th><th>Temp</th><th>HR</th><th>Status</th><th>Action</th></tr></thead>
          <tbody id="reportsTable"></tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="page" id="page-analytics">
    <div class="stat-grid" style="margin-bottom:20px">
      <div class="stat-card s-green"><div class="stat-label">Total Patients</div><div class="stat-val"><?php echo $totalPatients; ?></div></div>
      <div class="stat-card s-blue"><div class="stat-label">Male</div><div class="stat-val"><?php echo $genderM; ?></div></div>
      <div class="stat-card s-rose"><div class="stat-label">Female</div><div class="stat-val"><?php echo $genderF; ?></div></div>
      <div class="stat-card s-amber"><div class="stat-label">Seniors (60+)</div><div class="stat-val"><?php echo $ageSenior; ?></div></div>
    </div>
    <div class="analytics-grid">
      <div class="card">
        <div class="card-head"><div><div class="card-title">Weekly Patient Volume</div><div class="card-sub">Patients per day</div></div></div>
        <div class="card-body"><div class="chart-container"><canvas id="analyticsVol"></canvas></div></div>
      </div>
      <div class="card">
        <div class="card-head"><div><div class="card-title">Gender Distribution</div><div class="card-sub">Male vs Female</div></div></div>
        <div class="card-body"><div class="chart-container"><canvas id="analyticsGender"></canvas></div></div>
      </div>
      <div class="card">
        <div class="card-head"><div><div class="card-title">Vital Flags Breakdown</div><div class="card-sub">Count per condition</div></div></div>
        <div class="card-body"><div class="chart-container"><canvas id="analyticsFlags"></canvas></div></div>
      </div>
      <div class="card">
        <div class="card-head"><div><div class="card-title">Age Group Distribution</div><div class="card-sub">Child / Adult / Senior</div></div></div>
        <div class="card-body"><div class="chart-container"><canvas id="analyticsAge"></canvas></div></div>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><div><div class="card-title">Top Barangays by Patient Count</div><div class="card-sub">Patient volume per area</div></div></div>
      <div class="card-body"><div id="barangayBars" style="display:flex;flex-direction:column;gap:10px"></div></div>
    </div>
  </div>

  <div class="page" id="page-notifications">
    <div class="card">
      <div class="card-head">
        <div><div class="card-title">Vital Alert Notifications</div><div class="card-sub" id="notifSubCount">Loading…</div></div>
        <button class="btn-ghost" onclick="clearNotifUI()">Clear All</button>
      </div>
      <div class="card-body" id="notifList"></div>
    </div>
  </div>

  <div class="page" id="page-settings">
    <div class="settings-grid">
      <div class="card">
        <div class="card-head"><div><div class="card-title">🏥 Kiosk Information</div><div class="card-sub">Facility & location details</div></div></div>
        <div class="card-body">
          <div class="form-group"><label class="form-label">Facility Name</label><input class="form-input" type="text" value="RHU Pozorrubio"></div>
          <div class="form-group"><label class="form-label">Municipality</label><input class="form-input" type="text" value="Pozorrubio"></div>
          <div class="form-group"><label class="form-label">Province</label><input class="form-input" type="text" value="Pangasinan"></div>
          <div class="form-group"><label class="form-label">Kiosk Location</label><input class="form-input" type="text" value="Main Lobby"></div>
          <div class="form-group">
            <label class="form-label">Contact Number</label>
            <div style="display:flex;align-items:center;gap:0">
              <span style="background:var(--slate-100);border:1px solid var(--slate-200);border-right:none;border-radius:var(--radius) 0 0 var(--radius);padding:9px 12px;font-size:13px;color:var(--slate-500);font-weight:600;white-space:nowrap">+63</span>
              <input class="form-input" type="tel" id="contactNumber" style="border-radius:0 var(--radius) var(--radius) 0;border-left:none" placeholder="9XXXXXXXXX" maxlength="11" pattern="0?9[0-9]{9}" oninput="formatPHPhone(this)" value="">
            </div>
          </div>
          <button class="btn-primary" onclick="showToast('Kiosk information saved!')">Save Changes</button>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div><div class="card-title">🔐 Admin Account</div><div class="card-sub">Credentials & security</div></div></div>
        <div class="card-body">
          <div class="form-group"><label class="form-label">Admin Username</label><input class="form-input" type="text" value="<?php echo htmlspecialchars($_SESSION['admin_username']); ?>"></div>
          <div class="form-group"><label class="form-label">Email Address</label><input class="form-input" type="email" placeholder="admin@rhu.gov.ph"></div>
          <div class="form-group"><label class="form-label">Current Password</label><input class="form-input" type="password" placeholder="••••••••"></div>
          <div class="form-group"><label class="form-label">New Password</label><input class="form-input" type="password" placeholder="••••••••"></div>
          <div class="form-group"><label class="form-label">Confirm New Password</label><input class="form-input" type="password" placeholder="••••••••"></div>
          <button class="btn-primary" onclick="showToast('Password updated successfully!')">Update Credentials</button>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div><div class="card-title">🗄️ Data Management</div><div class="card-sub">Backup, export & archive</div></div></div>
        <div class="card-body">
          <div class="setting-row">
            <div><div class="setting-label">Auto Data Backup</div><div class="setting-sub">Daily backup to server at midnight</div></div>
            <div class="toggle" onclick="this.classList.toggle('off')"></div>
          </div>
          <div class="setting-row">
            <div><div class="setting-label">Auto-print Reports</div><div class="setting-sub">Print report after each scan session</div></div>
            <div class="toggle off" onclick="this.classList.toggle('off')"></div>
          </div>
          <div class="setting-row">
            <div><div class="setting-label">Archive Old Records</div><div class="setting-sub">Auto-archive records older than 1 year</div></div>
            <div class="toggle" onclick="this.classList.toggle('off')"></div>
          </div>
          <div style="margin-top:18px;display:flex;flex-direction:column;gap:10px">
            <div class="form-group" style="margin-bottom:8px">
              <label class="form-label">Export Format</label>
              <select class="form-select">
                <option>CSV (Spreadsheet)</option>
                <option>PDF Report</option>
                <option>JSON (Raw Data)</option>
              </select>
            </div>
            <button class="btn-primary" onclick="exportCSV('all'); showToast('Export started!')">Export All Records</button>
            <button class="btn-ghost" style="color:var(--red-600);border-color:#fca5a5" onclick="if(confirm('Archive records older than 1 year?')) showToast('Archiving completed!')">Archive Old Records</button>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><div><div class="card-title">🖥️ Kiosk Display</div><div class="card-sub">Screen & interface settings</div></div></div>
        <div class="card-body">
          <div class="setting-row">
            <div><div class="setting-label">Auto-sleep Screen</div><div class="setting-sub">Turn off display after inactivity</div></div>
            <div class="toggle" onclick="this.classList.toggle('off')"></div>
          </div>
          <div class="setting-row">
            <div><div class="setting-label">Show QR Code on Receipt</div><div class="setting-sub">Print QR linking to digital record</div></div>
            <div class="toggle" onclick="this.classList.toggle('off')"></div>
          </div>
          <div class="setting-row">
            <div><div class="setting-label">Welcome Screen Animation</div><div class="setting-sub">Show animated intro on idle</div></div>
            <div class="toggle" onclick="this.classList.toggle('off')"></div>
          </div>
          <div style="margin-top:16px">
            <div class="form-group">
              <label class="form-label">Language</label>
              <select class="form-select"><option>English</option><option>Filipino</option><option>Ilocano</option></select>
            </div>
            <div class="form-group">
              <label class="form-label">Screen Timeout (minutes)</label>
              <input class="form-input" type="number" value="5" min="1" max="60">
            </div>
            <button class="btn-primary" onclick="showToast('Display settings saved!')">Save Display Settings</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  </div>
</div>
</div>

<div class="drawer-overlay" id="drawerOverlay" onclick="closeDrawer()"></div>
<div class="drawer" id="drawer">
  <div class="drawer-head">
    <div class="drawer-av" id="drawerAv" style="cursor:zoom-in" onclick="zoomDrawerPhoto()"></div>
    <div>
      <div class="drawer-name" id="drawerName">—</div>
      <div class="drawer-id" id="drawerId">—</div>
    </div>
    <button class="drawer-close" onclick="closeDrawer()">✕</button>
  </div>
  <div class="drawer-body">
    <div class="drawer-section">
      <div class="drawer-section-title">Patient Information</div>
      <div class="info-grid" id="drawerInfo"></div>
    </div>
    <div class="drawer-section">
      <div class="drawer-section-title">Vital Signs</div>
      <div id="drawerVitals"></div>
    </div>
    <div class="drawer-section">
      <div class="drawer-section-title">Actions</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">
        <button class="btn-primary" onclick="openPrintModal()">Print Report</button>
        <button class="btn-ghost" style="color:var(--red-600)" onclick="showToast('Flagged for review')">Flag for Review</button>
      </div>
    </div>
  </div>
</div>

<div class="modal-overlay" id="printModal">
  <div class="modal">
    <div class="modal-title">Print Health Report</div>
    <div class="modal-sub">Select sections to include in the printed report.</div>
    <div style="display:flex;flex-direction:column;gap:10px">
      <label style="display:flex;align-items:center;gap:10px;font-size:13px;cursor:pointer"><input type="checkbox" checked> Patient Information</label>
      <label style="display:flex;align-items:center;gap:10px;font-size:13px;cursor:pointer"><input type="checkbox" checked> Vital Signs</label>
      <label style="display:flex;align-items:center;gap:10px;font-size:13px;cursor:pointer"><input type="checkbox" checked> BMI & Weight</label>
      <label style="display:flex;align-items:center;gap:10px;font-size:13px;cursor:pointer"><input type="checkbox"> Doctor's Remarks (blank)</label>
    </div>
    <div class="modal-actions">
      <button class="btn-outline" onclick="closePrintModal()">Cancel</button>
      <button class="btn-primary" onclick="window.print(); closePrintModal()">Print Now</button>
    </div>
  </div>
</div>

<div class="lightbox-overlay" id="lightboxOverlay" onclick="closeLightbox()">
  <span class="lightbox-close" onclick="closeLightbox()">✕</span>
  <img class="lightbox-img" id="lightboxImg" src="" style="display:none">
  <div class="lightbox-initials" id="lightboxInitials" style="display:none"></div>
  <div class="lightbox-name" id="lightboxName"></div>
</div>

<div class="alert-card-overlay" id="alertCardOverlay" onclick="if(event.target===this)closeAlertCard()">
  <div class="alert-card" id="alertCard">
    <div class="alert-card-banner" id="acBanner">
      <div class="alert-card-av" id="acAv"></div>
      <div class="alert-card-hd">
        <div class="alert-card-patient" id="acName">—</div>
        <div class="alert-card-type" id="acType">—</div>
      </div>
      <div class="alert-card-close" onclick="closeAlertCard()">✕</div>
    </div>
    <div class="alert-card-body">
      <div class="alert-info-row" id="acInfoRow"></div>
      <div class="alert-vitals-grid" id="acVitals"></div>
      <div class="alert-card-actions">
        <button class="btn-primary" id="acViewBtn">View Full Record</button>
        <button class="btn-ghost" onclick="closeAlertCard()">Dismiss</button>
      </div>
    </div>
  </div>
</div>

<div id="toast"></div>

<script>
const PATIENTS = [
<?php
$result->data_seek(0);
while($row = $result->fetch_assoc()){
  $status = ($row['systolic_bp']>=140||$row['temperature_c']>=37.5||$row['spo2_percent']<95||$row['pulse_bpm']>=100) ? 'warning' : 'normal';
  $photo = !empty($row['face_image']) ? base64_encode($row['face_image']) : '';
  $isoDate = date("Y-m-d", strtotime($row['recorded_at']));
  $timeFormatted = date("M d, Y h:i A", strtotime($row['recorded_at']));
  echo "{"
    ."id:'".addslashes($row['id'])."',"
    ."name:'".addslashes($row['first_name']." ".$row['last_name'])."',"
    ."barangay:'".addslashes($row['barangay']??'')."',"
    ."age:".intval($row['age']).","
    ."gender:'".addslashes($row['gender']??'')."',"
    ."weight:".floatval($row['weight_kg']).","
    ."height:".floatval($row['height_cm']).","
    ."bmi:".floatval($row['bmi']).","
    ."bp:'".intval($row['systolic_bp'])."/".intval($row['diastolic_bp'])."',"
    ."spo2:".floatval($row['spo2_percent']).","
    ."temp:".floatval($row['temperature_c']).","
    ."hr:".intval($row['pulse_bpm']).","
    ."time:'".addslashes($timeFormatted)."',"
    ."isoDate:'$isoDate',"
    ."status:'$status',"
    ."photo:'$photo'"
    ."},\n";
}
?>
];

const SAMPLES = [
  {id:'S001',name:'Maria Santos',barangay:'Poblacion District I',age:39,gender:'Female',weight:62.5,height:158,bmi:25.1,bp:'130/85',spo2:98,temp:37.2,hr:78,time:'Jun 3, 2026 08:15 AM',isoDate:'2026-06-03',status:'normal',photo:''},
  {id:'S002',name:'Juan Dela Cruz',barangay:'Alipangpang',age:52,gender:'Male',weight:80,height:170.5,bmi:27.5,bp:'150/95',spo2:96,temp:38.1,hr:92,time:'Jun 3, 2026 08:30 AM',isoDate:'2026-06-03',status:'warning',photo:''},
  {id:'S003',name:'Ana Reyes',barangay:'Balacag',age:34,gender:'Female',weight:55,height:162,bmi:20.9,bp:'118/76',spo2:97,temp:36.8,hr:72,time:'Jun 3, 2026 08:45 AM',isoDate:'2026-06-03',status:'normal',photo:''},
  {id:'S004',name:'Carlos Mendoza',barangay:'Laoac',age:59,gender:'Male',weight:90,height:168,bmi:31.9,bp:'145/90',spo2:92,temp:36.5,hr:105,time:'Jun 3, 2026 09:00 AM',isoDate:'2026-06-03',status:'warning',photo:''},
  {id:'S005',name:'Rosa Garcia',barangay:'Rosario',age:23,gender:'Female',weight:48,height:155,bmi:19.9,bp:'120/80',spo2:98,temp:37.6,hr:68,time:'Jun 3, 2026 09:15 AM',isoDate:'2026-06-03',status:'warning',photo:''},
];

const ALL = PATIENTS.length ? PATIENTS : SAMPLES;
let filtered = [...ALL];
let currentPatient = null;
let activePeriod = 'all';

const NOTIFICATIONS = <?php echo json_encode($notifications); ?>;
const WEEKLY        = <?php echo json_encode($weeklyData); ?>;
const HIGH_BP       = <?php echo intval($highBP); ?>;
const FEVER         = <?php echo intval($fever); ?>;
const LOW_SPO2      = <?php echo intval($lowSpo2); ?>;
const HIGH_HR       = <?php echo intval($highHR); ?>;
const GENDER_M      = <?php echo intval($genderM); ?>;
const GENDER_F      = <?php echo intval($genderF); ?>;
const AGE_CHILD     = <?php echo intval($ageChild); ?>;
const AGE_ADULT     = <?php echo intval($ageAdult); ?>;
const AGE_SENIOR    = <?php echo intval($ageSenior); ?>;

const PALETTE = ['#15803d','#0ea5e9','#7c3aed','#f59e0b','#e11d48','#0d9488'];

function toggleMobileSidebar() {
  const sidebar = document.getElementById('sidebarNav');
  const overlay = document.getElementById('sidebarOverlay');
  sidebar.classList.toggle('open');
  overlay.classList.toggle('open');
}

setInterval(() => {
  document.getElementById('clock').textContent =
    new Date().toLocaleTimeString('en-PH',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true});
}, 1000);

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.style.opacity = '1'; t.style.transform = 'translateY(0)';
  setTimeout(() => { t.style.opacity='0'; t.style.transform='translateY(8px)'; }, 2800);
}

function formatPHPhone(input) {
  let v = input.value.replace(/\D/g,'');
  if(v.startsWith('63')) v = '0' + v.slice(2);
  if(!v.startsWith('09') && v.length > 0) {
    if(v.startsWith('9')) v = '0' + v;
  }
  if(v.length > 11) v = v.slice(0,11);
  input.value = v;
}

const PAGE_META = {
  dashboard:     ['Dashboard',          'Overview & Monitoring'],
  patients:      ['Patients',           'Health Records'],
  vitals:        ['Vital Monitoring',  'Average Readings & Distribution'],
  reports:       ['Reports Printed',   'All generated health reports'],
  analytics:     ['Analytics',          'Patient statistics & trends'],
  notifications: ['Notifications',     'Vital Alerts'],
  settings:      ['Settings',           'System configuration'],
};

function nav(page, el) {
  document.querySelectorAll('.nav-link').forEach(n=>n.classList.remove('active'));
  if(el) el.classList.add('active');
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById('page-'+page).classList.add('active');
  const m = PAGE_META[page]||[page,''];
  document.getElementById('pageTitle').textContent = m[0];
  document.getElementById('pageSub').textContent   = m[1]||'';
  
  const sidebar = document.getElementById('sidebarNav');
  const overlay = document.getElementById('sidebarOverlay');
  if(sidebar.classList.contains('open')) {
    sidebar.classList.remove('open');
    overlay.classList.remove('open');
  }

  if(page==='patients')      { setPeriod('all'); }
  if(page==='vitals')        renderVitalsTable();
  if(page==='reports')       renderReports(ALL);
  if(page==='analytics')     renderAnalytics();
  if(page==='notifications') renderNotifications();
}

function getToday() { return new Date().toISOString().slice(0,10); }
function getWeekStart() {
  const d = new Date();
  const day = d.getDay();
  const diff = d.getDate() - day + (day===0?-6:1);
  return new Date(d.setDate(diff)).toISOString().slice(0,10);
}
function getMonthStart() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1).toISOString().slice(0,10);
}

function setPeriod(period) {
  activePeriod = period;
  ['All','Today','Week','Month'].forEach(t => {
    const el = document.getElementById('tab'+t);
    if(el) el.classList.remove('active');
  });
  const tabMap = {all:'tabAll',today:'tabToday',week:'tabWeek',month:'tabMonth'};
  if(tabMap[period]) document.getElementById(tabMap[period]).classList.add('active');

  document.getElementById('dateFrom').value = '';
  document.getElementById('dateTo').value   = '';

  let data;
  const today = getToday();
  const weekStart = getWeekStart();
  const monthStart = getMonthStart();

  if(period==='today')  data = ALL.filter(p=>p.isoDate===today);
  else if(period==='week')  data = ALL.filter(p=>p.isoDate>=weekStart && p.isoDate<=today);
  else if(period==='month') data = ALL.filter(p=>p.isoDate>=monthStart && p.isoDate<=today);
  else data = [...ALL];

  renderPatients(data);
  document.getElementById('patientSearch').value='';
}

function filterByDateRange() {
  const from = document.getElementById('dateFrom').value;
  const to   = document.getElementById('dateTo').value;
  if(!from && !to) { setPeriod('all'); return; }
  ['tabAll','tabToday','tabWeek','tabMonth'].forEach(id=>{
    const el=document.getElementById(id);
    if(el) el.classList.remove('active');
  });
  activePeriod='custom';
  let data = ALL.filter(p=>{
    if(from && p.isoDate < from) return false;
    if(to   && p.isoDate > to)   return false;
    return true;
  });
  renderPatients(data);
}

function clearDateRange() {
  document.getElementById('dateFrom').value='';
  document.getElementById('dateTo').value='';
  setPeriod('all');
}

function getDataForExport(mode) {
  const today = getToday();
  const weekStart = getWeekStart();
  const monthStart = getMonthStart();
  const from = document.getElementById('dateFrom')?.value||'';
  const to   = document.getElementById('dateTo')?.value||'';

  if(mode==='today')    return ALL.filter(p=>p.isoDate===today);
  if(mode==='week')     return ALL.filter(p=>p.isoDate>=weekStart && p.isoDate<=today);
  if(mode==='month')    return ALL.filter(p=>p.isoDate>=monthStart && p.isoDate<=today);
  if(mode==='range')    return ALL.filter(p=>(!from||p.isoDate>=from)&&(!to||p.isoDate<=to));
  if(mode==='filtered') return filtered;
  return ALL;
}

function exportCSV(mode='all') {
  const data = getDataForExport(mode);
  if(!data.length){ showToast('No records in this period to export.'); return; }
  const rows=[['ID','Name','Barangay','Age','Gender','Weight','Height','BMI','BP','SpO2','Temp','HR','Time','Status']];
  data.forEach(p=>rows.push([p.id,p.name,p.barangay,p.age,p.gender,p.weight,p.height,p.bmi,p.bp,p.spo2,p.temp,p.hr,p.time,p.status]));
  const csv=rows.map(r=>r.map(v=>`"${v}"`).join(',')).join('\n');
  const suffix = mode==='all'?'all':mode==='filtered'?'current_view':mode;
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));
  a.download=`health_records_${suffix}.csv`;
  a.click();
  showToast(`CSV exported (${data.length} records)!`);
}

function toggleExportMenu() {
  document.getElementById('exportMenu').classList.toggle('open');
}
function closeExportMenu() {
  document.getElementById('exportMenu').classList.remove('open');
}
document.addEventListener('click', e=>{
  const wrap = document.getElementById('exportWrap');
  if(wrap && !wrap.contains(e.target)) closeExportMenu();
});

function avatarEl(p, size=30) {
  const clickHandler = `onclick="event.stopPropagation();openLightbox(ALL.find(x=>x.id=='${p.id}'))" class="photo-zoomable"`;
  if(p.photo) return `<div class="pt-av" style="width:${size}px;height:${size}px;cursor:zoom-in" ${clickHandler}><img src="data:image/jpeg;base64,${p.photo}" style="width:100%;height:100%;object-fit:cover"></div>`;
  const initials = p.name.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase();
  const col = PALETTE[(p.id.charCodeAt(0)||0) % PALETTE.length];
  return `<div class="pt-av" style="width:${size}px;height:${size}px;background:${col}" ${clickHandler}>${initials}</div>`;
}

function openLightbox(p) {
  if(!p) return;
  const overlay=document.getElementById('lightboxOverlay'),
        img=document.getElementById('lightboxImg'),
        ini=document.getElementById('lightboxInitials');
  document.getElementById('lightboxName').textContent=p.name;
  if(p.photo){ img.src='data:image/jpeg;base64,'+p.photo; img.style.display='block'; ini.style.display='none'; }
  else {
    const initials=p.name.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase();
    ini.textContent=initials; ini.style.background=PALETTE[(p.id.charCodeAt(0)||0)%PALETTE.length];
    ini.style.display='flex'; img.style.display='none';
  }
  overlay.classList.add('open');
}
function closeLightbox(){ document.getElementById('lightboxOverlay').classList.remove('open'); }
function zoomDrawerPhoto(){ if(currentPatient) openLightbox(currentPatient); }
document.addEventListener('keydown', e=>{
  if(e.key==='Escape'){ closeLightbox(); closeAlertCard(); closePrintModal(); }
});

function openAlertCard(patientName) {
  const p = ALL.find(x=>x.name.toLowerCase()===patientName.toLowerCase());
  if(!p) return;
  let type='', bannerClass='', typeClass='';
  if(parseInt(p.bp)>=140)  { type='⚠ High Blood Pressure'; bannerClass='banner-red';   typeClass='type-red'; }
  else if(p.temp>=37.5)    { type='🌡 Fever Detected';      bannerClass='banner-amber'; typeClass='type-amber'; }
  else if(p.spo2<95)       { type='💧 Low SpO2 Level';      bannerClass='banner-blue';  typeClass='type-blue'; }
  else if(p.hr>=100)       { type='❤ High Heart Rate';      bannerClass='banner-red';   typeClass='type-red'; }
  const banner=document.getElementById('acBanner');
  banner.className='alert-card-banner '+bannerClass;
  const av=document.getElementById('acAv');
  if(p.photo){ av.innerHTML=`<img src="data:image/jpeg;base64,${p.photo}">`; av.style.background=''; }
  else{ const initials=p.name.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase(); av.innerHTML=initials; av.style.background=PALETTE[(p.id.charCodeAt(0)||0)%PALETTE.length]; }
  document.getElementById('acName').textContent=p.name;
  const acType=document.getElementById('acType');
  acType.textContent=type; acType.className='alert-card-type '+typeClass;
  document.getElementById('acInfoRow').innerHTML=`
    <span class="alert-info-pill">📍 ${p.barangay}</span>
    <span class="alert-info-pill">🗓 Age ${p.age}</span>
    <span class="alert-info-pill">${p.gender}</span>
    <span class="alert-info-pill">🕐 ${p.time}</span>`;
  const bpHigh=parseInt(p.bp)>=140, spo2Low=p.spo2<95, tempHigh=p.temp>=37.5, hrHigh=p.hr>=100, bmiFlag=p.bmi>27.5||p.bmi<18.5;
  document.getElementById('acVitals').innerHTML=`
    <div class="alert-vital-tile ${bpHigh?'flagged':''}"><div class="avt-label">Blood Pressure</div><div class="avt-val ${bpHigh?'danger':''}">${p.bp}</div><div style="font-size:10px;color:var(--slate-400);margin-top:2px">mmHg</div></div>
    <div class="alert-vital-tile ${spo2Low?'flagged':''}"><div class="avt-label">SpO2</div><div class="avt-val ${spo2Low?'danger':''}">${p.spo2}%</div><div style="font-size:10px;color:var(--slate-400);margin-top:2px">oxygen sat.</div></div>
    <div class="alert-vital-tile ${tempHigh?'flagged-amber':''}"><div class="avt-label">Temperature</div><div class="avt-val ${tempHigh?'warn':''}">${p.temp}°C</div><div style="font-size:10px;color:var(--slate-400);margin-top:2px">${tempHigh?'Fever':'Normal'}</div></div>
    <div class="alert-vital-tile ${hrHigh?'flagged':''}"><div class="avt-label">Heart Rate</div><div class="avt-val ${hrHigh?'danger':''}">${p.hr}</div><div style="font-size:10px;color:var(--slate-400);margin-top:2px">bpm</div></div>
    <div class="alert-vital-tile"><div class="avt-label">Weight</div><div class="avt-val">${p.weight}</div><div style="font-size:10px;color:var(--slate-400);margin-top:2px">kg</div></div>
    <div class="alert-vital-tile ${bmiFlag?'flagged-amber':''}"><div class="avt-label">BMI</div><div class="avt-val ${bmiFlag?'warn':''}">${p.bmi}</div><div style="font-size:10px;color:var(--slate-400);margin-top:2px">${p.bmi>27.5?'Overweight':p.bmi<18.5?'Underweight':'Normal'}</div></div>`;
  document.getElementById('acViewBtn').onclick=()=>{ closeAlertCard(); openDrawer(p.id); };
  document.getElementById('alertCardOverlay').classList.add('open');
}
function closeAlertCard(){ document.getElementById('alertCardOverlay').classList.remove('open'); }

function renderRecent() {
  document.getElementById('recentTable').innerHTML = ALL.slice(0,8).map(p=>`
    <tr onclick="openDrawer('${p.id}')">
      <td><div class="pt-cell">${avatarEl(p)}<span class="pt-name">${p.name}</span></div></td>
      <td>${p.barangay}</td>
      <td class="mono">${p.time.split(' ').slice(-2).join(' ')}</td>
      <td class="mono" style="color:${parseInt(p.bp)>=140?'var(--red-600)':'inherit'}">${p.bp}</td>
      <td class="mono" style="color:${p.spo2<95?'var(--red-600)':'var(--green-700)'}">${p.spo2}%</td>
      <td class="mono" style="color:${p.temp>=37.5?'var(--amber-500)':'inherit'}">${p.temp}°C</td>
      <td><span class="badge ${p.status==='warning'?'badge-warn':'badge-ok'}">${p.status==='warning'?'Flagged':'Normal'}</span></td>
    </tr>`).join('');
}

function renderPatients(data) {
  filtered = [...data];
  document.getElementById('ptCount').textContent = data.length+' record'+(data.length!==1?'s':'');
  document.getElementById('patientTable').innerHTML = data.length ? data.map(p=>`
    <tr onclick="openDrawer('${p.id}')">
      <td><div class="pt-cell">${avatarEl(p)}<div><div class="pt-name">${p.name}</div><div class="pt-sub">${p.age}y ${p.gender.charAt(0)}</div></div></div></td>
      <td>${p.barangay}</td>
      <td>${p.age} / ${p.gender}</td>
      <td class="mono">${p.weight} kg</td>
      <td class="mono">${p.height} cm / ${p.bmi}</td>
      <td class="mono" style="font-weight:700;color:${parseInt(p.bp)>=140?'var(--red-600)':'inherit'}">${p.bp}</td>
      <td class="mono" style="color:${p.spo2<95?'var(--red-600)':'var(--green-700)'}">${p.spo2}%</td>
      <td class="mono" style="color:${p.temp>=37.5?'var(--amber-500)':'inherit'}">${p.temp}°C</td>
      <td class="mono" style="color:${p.hr>=100?'var(--red-600)':'inherit'}">${p.hr} bpm</td>
      <td style="font-size:12px;color:var(--slate-400)">${p.time}</td>
      <td><span class="badge ${p.status==='warning'?'badge-warn':'badge-ok'}">${p.status==='warning'?'Flagged':'Normal'}</span></td>
    </tr>`).join('')
  : '<tr><td colspan="11" class="empty-state">No records found for this period.</td></tr>';
}

function renderVitalsTable() {
  document.getElementById('vitalsTable').innerHTML = ALL.map(p=>`
    <tr onclick="openDrawer('${p.id}')">
      <td><div class="pt-cell">${avatarEl(p)}<span class="pt-name">${p.name}</span></div></td>
      <td class="mono" style="color:${parseInt(p.bp)>=140?'var(--red-600)':'inherit'}">${p.bp}</td>
      <td class="mono" style="color:${p.spo2<95?'var(--red-600)':'var(--green-700)'}">${p.spo2}%</td>
      <td class="mono" style="color:${p.temp>=37.5?'var(--amber-500)':'inherit'}">${p.temp}°C</td>
      <td class="mono" style="color:${p.hr>=100?'var(--red-600)':'inherit'}">${p.hr} bpm</td>
      <td class="mono">${p.weight} kg</td>
      <td class="mono">${p.bmi}</td>
      <td style="font-size:12px;color:var(--slate-400)">${p.time}</td>
      <td><span class="badge ${p.status==='warning'?'badge-warn':'badge-ok'}">${p.status==='warning'?'Flagged':'Normal'}</span></td>
    </tr>`).join('');
}

function renderReports(data) {
  document.getElementById('reportCount').textContent = data.length+' reports';
  document.getElementById('reportsTable').innerHTML = data.map(p=>`
    <tr>
      <td><div class="pt-cell">${avatarEl(p)}<div><div class="pt-name">${p.name}</div><div class="pt-sub">${p.barangay}</div></div></div></td>
      <td>${p.barangay}</td>
      <td style="font-size:12px;color:var(--slate-500)">${p.time}</td>
      <td class="mono" style="color:${parseInt(p.bp)>=140?'var(--red-600)':'inherit'}">${p.bp}</td>
      <td class="mono" style="color:${p.spo2<95?'var(--red-600)':'var(--green-700)'}">${p.spo2}%</td>
      <td class="mono" style="color:${p.temp>=37.5?'var(--amber-500)':'inherit'}">${p.temp}°C</td>
      <td class="mono">${p.hr} bpm</td>
      <td><span class="badge ${p.status==='warning'?'badge-warn':'badge-ok'}">${p.status==='warning'?'Flagged':'Normal'}</span></td>
      <td><button class="btn-ghost" style="padding:5px 10px;font-size:11px" onclick="openDrawerAndPrint('${p.id}')">Print</button></td>
    </tr>`).join('');
}
function filterReports(q){ q=q.toLowerCase(); renderReports(ALL.filter(p=>p.name.toLowerCase().includes(q)||p.barangay.toLowerCase().includes(q))); }
function filterReportStatus(s){ renderReports(s?ALL.filter(p=>p.status===s):ALL); }

function renderAnalytics() {
  const brgyCounts={};
  ALL.forEach(p=>{ if(p.barangay) brgyCounts[p.barangay]=(brgyCounts[p.barangay]||0)+1; });
  const sorted=Object.entries(brgyCounts).sort((a,b)=>b[1]-a[1]).slice(0,8);
  const max=sorted[0]?.[1]||1;
  document.getElementById('barangayBars').innerHTML=sorted.map(([name,count])=>`
    <div>
      <div style="display:flex;justify-content:space-between;margin-bottom:4px">
        <span style="font-size:12.5px;font-weight:600">${name}</span>
        <span style="font-family:'DM Mono',monospace;font-size:12px">${count}</span>
      </div>
      <div style="height:7px;background:var(--slate-100);border-radius:999px">
        <div style="height:100%;width:${Math.round(count/max*100)}%;background:var(--green-500);border-radius:999px;transition:.6s"></div>
      </div>
    </div>`).join('');
  setTimeout(()=> {
    mkChart('analyticsVol','bar',['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
      [{data:WEEKLY,backgroundColor:'rgba(22,163,74,.2)',borderColor:'#16a34a',borderWidth:2,borderRadius:5}]);
    mkChart('analyticsGender','doughnut',['Male','Female'],
      [{data:[GENDER_M,GENDER_F],backgroundColor:['#dbeafe','#fce7f3'],borderColor:['#2563eb','#db2777'],borderWidth:2}]);
    mkChart('analyticsFlags','bar',['High BP','Fever','Low SpO2','High HR'],
      [{data:[HIGH_BP,FEVER,LOW_SPO2,HIGH_HR],backgroundColor:['#fee2e2','#fef3c7','#dbeafe','#ede9fe'],borderColor:['#dc2626','#f59e0b','#2563eb','#7c3aed'],borderWidth:2,borderRadius:5}]);
    mkChart('analyticsAge','pie',['Children','Adults','Seniors'],
      [{data:[AGE_CHILD,AGE_ADULT,AGE_SENIOR],backgroundColor:['#dbeafe','#dcfce7','#fef3c7'],borderColor:['#2563eb','#16a34a','#f59e0b'],borderWidth:2}]);
  },50);
}

function renderNotifications() {
  const sub=document.getElementById('notifSubCount'), list=document.getElementById('notifList');
  if(!NOTIFICATIONS.length){ sub.textContent='0 alerts'; list.innerHTML='<div class="empty-state">No abnormal vital records detected.</div>'; return; }
  sub.textContent=NOTIFICATIONS.length+' alert'+(NOTIFICATIONS.length!==1?'s':'');
  list.innerHTML=NOTIFICATIONS.map(n=>{
    const pip=n.alert.includes('FEVER')||n.alert.includes('SpO2')?'pip-amber':'pip-red';
    const safeName=n.name.replace(/'/g,"\\'");
    return `<div class="alert-row" style="cursor:pointer;border-radius:var(--radius);padding:14px 10px;margin:0 -10px;transition:background .12s"
      onmouseover="this.style.background='var(--green-50)'" onmouseout="this.style.background=''"
      onclick="openAlertCard('${safeName}')">
      <div class="alert-pip ${pip}"></div>
      <div style="flex:1">
        <div class="alert-title">${n.alert}</div>
        <div class="alert-meta">${n.time} &bull; <span style="color:var(--green-600);font-size:11px">Click to view patient details →</span></div>
      </div>
    </div>`;
  }).join('');
}
function clearNotifUI(){ document.getElementById('notifList').innerHTML='<div class="empty-state">All notifications cleared.</div>'; document.getElementById('notifSubCount').textContent='0 alerts'; }

function renderDashAlerts() {
  const alerts=ALL.filter(p=>p.status==='warning').slice(0,6);
  if(!alerts.length){ document.getElementById('dashAlerts').innerHTML='<div class="empty-state" style="padding:20px">No active alerts.</div>'; return; }
  document.getElementById('dashAlerts').innerHTML=alerts.map(p=>{
    let type='', meta='', pip='pip-red';
    if(parseInt(p.bp)>=140)  { type='High BP';   meta=p.bp+' mmHg'; }
    else if(p.temp>=37.5)    { type='Fever';      meta=p.temp+'°C'; pip='pip-amber'; }
    else if(p.spo2<95)       { type='Low SpO2';   meta=p.spo2+'%';  pip='pip-amber'; }
    else if(p.hr>=100)       { type='High HR';    meta=p.hr+' bpm'; }
    const safeName=p.name.replace(/'/g,"\\'");
    return `<div class="alert-row" style="cursor:pointer;border-radius:var(--radius);padding:14px 6px;margin:0 -6px;transition:background .12s"
      onmouseover="this.style.background='var(--green-50)'" onmouseout="this.style.background=''"
      onclick="openAlertCard('${safeName}')">
      <div class="alert-pip ${pip}"></div>
      <div>
        <div class="alert-title">${type} — ${p.name}</div>
        <div class="alert-meta">${meta} &bull; ${p.time.split(' ').slice(-2).join(' ')}</div>
      </div>
    </div>`;
  }).join('');
}

const FILTER_IDS=['sf','bpf','tf','sf2','af'];
function resetFilters(except){ FILTER_IDS.forEach(id=>{ if(id!==except){ const el=document.getElementById(id); if(el) el.selectedIndex=0; } }); }
function filterPatients(q){ q=q.toLowerCase(); renderPatients(ALL.filter(p=>p.name.toLowerCase().includes(q)||p.barangay.toLowerCase().includes(q)||p.id.toString().includes(q))); }
function filterByStatus(s){ resetFilters('sf'); renderPatients(s?ALL.filter(p=>p.status===s):ALL); }
function filterByBP(t){ resetFilters('bpf'); renderPatients(t?ALL.filter(p=>t==='high'?parseInt(p.bp)>=140:parseInt(p.bp)<140):ALL); }
function filterByTemp(t){ resetFilters('tf'); renderPatients(t?ALL.filter(p=>t==='high'?p.temp>=38.5:t==='fever'?p.temp>=37.5&&p.temp<38.5:p.temp>=36&&p.temp<37.5):ALL); }
function filterBySpO2(t){ resetFilters('sf2'); renderPatients(t?ALL.filter(p=>t==='critical'?p.spo2<90:t==='low'?p.spo2>=90&&p.spo2<95:p.spo2>=95):ALL); }
function filterByAddress(v){ resetFilters('af'); renderPatients((!v||v==='')?ALL:ALL.filter(p=>p.barangay.trim().toLowerCase()===v.trim().toLowerCase())); }

function openDrawer(id) {
  const p=ALL.find(x=>x.id==id||x.id===id);
  if(!p) return;
  currentPatient=p;
  const av=document.getElementById('drawerAv');
  if(p.photo){ av.innerHTML=`<img src="data:image/jpeg;base64,${p.photo}" style="width:100%;height:100%;object-fit:cover;">`; }
  else{ const initials=p.name.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase(); av.textContent=initials; av.style.background=PALETTE[(p.id.charCodeAt(0)||0)%PALETTE.length]; }
  document.getElementById('drawerName').textContent=p.name;
  document.getElementById('drawerId').textContent='Record #'+p.id+' · '+p.time;
  document.getElementById('drawerInfo').innerHTML=`
    <div class="info-tile"><div class="info-tile-label">Age</div><div class="info-tile-val">${p.age} years</div></div>
    <div class="info-tile"><div class="info-tile-label">Gender</div><div class="info-tile-val">${p.gender}</div></div>
    <div class="info-tile"><div class="info-tile-label">Barangay</div><div class="info-tile-val">${p.barangay}</div></div>
    <div class="info-tile"><div class="info-tile-label">Status</div><div class="info-tile-val"><span class="badge ${p.status==='warning'?'badge-warn':'badge-ok'}">${p.status==='warning'?'Flagged':'Normal'}</span></div></div>`;
  const vitals=[
    {n:'Blood Pressure',v:p.bp+' mmHg',  flag:parseInt(p.bp)>=140},
    {n:'SpO2',          v:p.spo2+'%',    flag:p.spo2<95},
    {n:'Temperature',   v:p.temp+'°C',   flag:p.temp>=37.5},
    {n:'Heart Rate',    v:p.hr+' bpm',   flag:p.hr>=100},
    {n:'Weight',        v:p.weight+' kg',flag:false},
    {n:'Height',        v:p.height+' cm',flag:false},
    {n:'BMI',           v:p.bmi,         flag:p.bmi>27.5||p.bmi<18.5},
  ];
  document.getElementById('drawerVitals').innerHTML=vitals.map(v=>`
    <div class="vital-row">
      <div class="vital-name">${v.n}</div>
      <div class="vital-val" style="color:${v.flag?'var(--red-600)':'var(--slate-800)'}">${v.v}</div>
      ${v.flag?'<span class="badge badge-alert" style="font-size:10px">Alert</span>':''}
    </div>`).join('');
  document.getElementById('drawerOverlay').classList.add('open');
  document.getElementById('drawer').classList.add('open');
}
function closeDrawer(){ document.getElementById('drawerOverlay').classList.remove('open'); document.getElementById('drawer').classList.remove('open'); currentPatient=null; }
function openDrawerAndPrint(id){ openDrawer(id); setTimeout(openPrintModal,300); }
function openPrintModal(){ document.getElementById('printModal').classList.add('open'); }
function closePrintModal(){ document.getElementById('printModal').classList.remove('open'); }

const chartInstances={};
function mkChart(id,type,labels,datasets,opts={}) {
  if(chartInstances[id]) chartInstances[id].destroy();
  const ctx=document.getElementById(id);
  if(!ctx) return;
  chartInstances[id]=new Chart(ctx.getContext('2d'),{
    type, data:{labels,datasets},
    options:{responsive:true,maintainAspectRatio:false,
      plugins:{legend:{display:type==='doughnut'||type==='pie',position:'right',
        labels:{font:{family:'DM Sans',size:11},color:'#64748b',boxWidth:10,padding:10}}},
      scales:(type==='bar')?{
        x:{grid:{display:false},ticks:{color:'#94a3b8',font:{family:'DM Mono',size:10}}},
        y:{grid:{color:'#f1f5f9'},ticks:{color:'#94a3b8',font:{family:'DM Mono',size:10}}}}:{},
      ...opts}
  });
}

function init(){
  const cnt=NOTIFICATIONS.length;
  document.getElementById('topNotifBadge').textContent=cnt;
  document.getElementById('topNotifBadge').style.display=cnt>0?'flex':'none';
  document.getElementById('navNotifBadge').textContent=cnt;
  document.getElementById('navNotifBadge').style.display=cnt>0?'inline-block':'none';
  renderRecent();
  renderDashAlerts();
  mkChart('volChart','bar',['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
    [{data:WEEKLY,backgroundColor:'rgba(22,163,74,.15)',borderColor:'#16a34a',borderWidth:2,borderRadius:5}]);
  mkChart('flagChart','doughnut',['High BP','Fever','Low SpO2','High HR'],
    [{data:[HIGH_BP,FEVER,LOW_SPO2,HIGH_HR],backgroundColor:['#fee2e2','#fef3c7','#dbeafe','#ede9fe'],borderColor:['#dc2626','#f59e0b','#2563eb','#7c3aed'],borderWidth:2}]);
  mkChart('genderChart','doughnut',['Male','Female'],
    [{data:[GENDER_M,GENDER_F],backgroundColor:['#dbeafe','#fce7f3'],borderColor:['#2563eb','#db2777'],borderWidth:2}]);
  setTimeout(()=>{
    const normal=ALL.filter(p=>parseInt(p.bp)<140).length;
    const high=ALL.filter(p=>parseInt(p.bp)>=140).length;
    mkChart('bpDistChart','doughnut',['Normal BP','High BP'],
      [{data:[normal,high],backgroundColor:['#dcfce7','#fee2e2'],borderColor:['#16a34a','#dc2626'],borderWidth:2}]);
  },100);
}
init();
</script>
</body>
</html>