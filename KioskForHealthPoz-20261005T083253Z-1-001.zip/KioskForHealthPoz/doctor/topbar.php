<?php
$pageTitle = $pageTitle ?? 'Dashboard';
$pageSub = $pageSub ?? 'Overview & Monitoring';
?>
<div class="topbar">
  <button class="menu-btn" onclick="toggleMobileSidebar()" title="Toggle Sidebar">
    <svg viewBox="0 0 24 24"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
  </button>
  <div>
    <span class="topbar-title" id="pageTitle"><?= htmlspecialchars($pageTitle) ?></span>
    <span class="topbar-sub" id="pageSub"><?= htmlspecialchars($pageSub) ?></span>
  </div>
  <div class="topbar-right">
    <button class="topbar-btn" title="Notifications" onclick="nav('notifications', document.querySelectorAll('.nav-link')[6])">
      <svg viewBox="0 0 24 24"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
      <span class="notif-dot" id="topNotifBadge" style="display:none">0</span>
    </button>
    <button class="topbar-btn" title="Refresh" onclick="location.reload()">
      <svg viewBox="0 0 24 24"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>
    </button>
    <div class="clock-pill" id="clock">00:00:00</div>
  </div>
</div>