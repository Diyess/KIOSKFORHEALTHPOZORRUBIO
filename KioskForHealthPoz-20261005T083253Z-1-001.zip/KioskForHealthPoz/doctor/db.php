<?php

$conn = new mysqli("localhost", "root", "", "medical_kiosk");

if ($conn->connect_error) {
    die("Database connection failed");
}

?>